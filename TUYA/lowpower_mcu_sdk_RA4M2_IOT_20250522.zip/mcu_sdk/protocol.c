/**********************************Copyright (c)**********************************
**                       版权所有 (C), 2015-2020, 涂鸦科技
**
**                             http://www.tuya.com
**
*********************************************************************************/
/**
 * @file    protocol.c
 * @author  涂鸦综合协议开发组
 * @version v1.0.5
 * @date    2021.10.19
 * @brief                
 *                       *******非常重要，一定要看哦！！！********
 *          1. 用户在此文件中实现数据下发/上报功能
 *          2. DP的ID/TYPE及数据处理函数都需要用户按照实际定义实现
 *          3. 当开始某些宏定义后需要用户实现代码的函数内部有#err提示,完成函数后请删除该#err
 */

/****************************** 免责声明 ！！！ *******************************
由于MCU类型和编译环境多种多样，所以此代码仅供参考，用户请自行把控最终代码质量，
涂鸦不对MCU功能结果负责。
******************************************************************************/

/******************************************************************************
                                移植须知:
1:MCU必须在while中直接调用mcu_api.c内的wifi_uart_service()函数
2:程序正常初始化完成后,建议不进行关串口中断,如必须关中断,关中断时间必须短,关中断会引起串口数据包丢失
3:请勿在中断/定时器中断内调用上报函数
******************************************************************************/

#include "wifi.h"
         
/******************************************************************************
                              第一步:初始化
1:在需要使用到wifi相关文件的文件中include "wifi.h"
2:在MCU初始化中调用mcu_api.c文件中的wifi_protocol_init()函数
3:将MCU串口单字节发送函数填入protocol.c文件中uart_transmit_output函数内,并删除#error
4:在MCU串口接收函数中调用mcu_api.c文件内的uart_receive_input函数,并将接收到的字节作为参数传入
5:单片机进入while循环后调用mcu_api.c文件内的wifi_uart_service()函数
******************************************************************************/

/******************************************************************************
                        1:dp数据点序列类型对照表
          **此为自动生成代码,如在开发平台有相关修改请重新下载MCU_SDK**         
******************************************************************************/
const DOWNLOAD_CMD_S download_cmd[] =
{
  {DPID_BATTERY_PERCENTAGE, DP_TYPE_VALUE},
  {DPID_TEMP_CURRENT, DP_TYPE_VALUE},
  {DPID_SHOCK_STATE, DP_TYPE_ENUM},
};



/******************************************************************************
                           2:串口单字节发送函数
请将MCU串口发送函数填入该函数内,并将接收到的数据作为参数传入串口发送函数
******************************************************************************/

/**
 * @brief  串口发送数据
 * @param[in] {value} 串口要发送的1字节数据
 * @return Null
 * @note   请在此函数中填写MCU串口发送功能，并将接收到的数据作为参数传递给串口发送函数
 */
void uart_transmit_output(u8 value)
{
    #error "请将MCU串口发送函数填入该函数,并删除该行"
  
/*
    //示例:
    extern void Uart_PutChar(u8 value);
    Uart_PutChar(value);	                                //串口发送函数
*/
}

/******************************************************************************
                            1:所有数据上报处理
当前函数处理全部数据上报(包括可下发/可上报和只上报)
  需要用户按照实际情况实现:
  1:需要实现可下发/可上报数据点上报
  2:需要实现只上报数据点上报
此函数为MCU内部必须调用
用户也可调用此函数实现全部数据上报
******************************************************************************/

//自动化生成数据上报函数

/**
 * @brief  系统所有dp点信息上传,实现APP和muc数据同步
 * @param  Null
 * @return Null
 * @note   此函数SDK内部需调用，MCU必须实现该函数内数据上报功能，包括只上报和可上报可下发型数据
 */
void all_data_update(void)
{
    #error "请在此处理可下发可上报数据及只上报数据示例,处理完成后删除该行"
    /* 
    //此代码为平台自动生成，请按照实际数据修改每个可下发可上报函数和只上报函数
    mcu_dp_value_update(DPID_BATTERY_PERCENTAGE,当前电池电量); //VALUE型数据上报;
    mcu_dp_value_update(DPID_TEMP_CURRENT,当前当前温度); //VALUE型数据上报;
    mcu_dp_enum_update(DPID_SHOCK_STATE,当前震动状态); //枚举型数据上报;

    */
}

/**
 * @brief  记录型数据组合上报
 * @param[in] {time} 时间数据长度7,首字节表示是否传输标志位，其余依次为年、月、日、时、分、秒
 * @param[in] {dp_bool}   bool型dpid号
 * @param[in] {v_bool}    bool型dp对应值
 * @param[in] {dp_enum}   enum型dpid号
 * @param[in] {v_enum}    enum型dp对应值
 * @param[in] {dp_value}  value型dpid号
 * @param[in] {v_value}   value型dp对应值
 * @param[in] {dp_string} string型dpid号
 * @param[in] {v_string}  string型dp对应值
 * @param[in] {len}       string长度
 * @return SUCCESS(1) or ERROR(0)
 * @note   当需要上报记录数据时调用该函数
 */
u8 dp_record_combine_update(u8 time[],
                                       u8 dp_bool,u8 v_bool,
                                       u8 dp_enum,u8 v_enum,
                                       u8 dp_value,u8 v_value,
                                       u8 dp_string,u8 v_string[],u8 len)
{
    u16 length = 0;

    if(stop_update_flag == ENABLE)
        return SUCCESS;

    //local_time
    length = set_wifi_uart_buffer(length,(u8 *)time,7);

    //bool
    length = set_wifi_uart_byte(length,dp_bool);
    length = set_wifi_uart_byte(length,DP_TYPE_BOOL);
    length = set_wifi_uart_byte(length,0);
    length = set_wifi_uart_byte(length,1);
    if(v_bool == FALSE)
    {
        length = set_wifi_uart_byte(length,FALSE);
    }
    else
    {
        length = set_wifi_uart_byte(length,1);
    }
    //enum
    length = set_wifi_uart_byte(length,dp_enum);
    length = set_wifi_uart_byte(length,DP_TYPE_ENUM);
    length = set_wifi_uart_byte(length,0);
    length = set_wifi_uart_byte(length,1);
    length = set_wifi_uart_byte(length,v_enum);
    //value
    length = set_wifi_uart_byte(length,dp_value);
    length = set_wifi_uart_byte(length,DP_TYPE_VALUE);
    length = set_wifi_uart_byte(length,0);
    length = set_wifi_uart_byte(length,4);
    length = set_wifi_uart_byte(length,v_value >> 24);
    length = set_wifi_uart_byte(length,v_value >> 16);
    length = set_wifi_uart_byte(length,v_value >> 8);
    length = set_wifi_uart_byte(length,v_value & 0xff);
    //string
    length = set_wifi_uart_byte(length,dp_string);
    length = set_wifi_uart_byte(length,DP_TYPE_STRING);
    length = set_wifi_uart_byte(length,len / 0x100);
    length = set_wifi_uart_byte(length,len % 0x100);
    length = set_wifi_uart_buffer(length,(u8 *)v_string,len);

    wifi_uart_write_frame(STATE_RC_UPLOAD_CMD,length);

    return SUCCESS;
}

/******************************************************************************
                                WARNING!!!    
                            2:所有数据下发处理
自动化代码模板函数,具体请用户自行实现数据处理
******************************************************************************/



/******************************************************************************
                                WARNING!!!                     
该部分函数用户请勿修改！！
******************************************************************************/

/**
 * @brief  dp下发处理函数
 * @param[in] {dpid} dpid 序号
 * @param[in] {value} dp数据缓冲区地址
 * @param[in] {length} dp数据长度
 * @return dp处理结果
 * -           0(ERROR): 失败
 * -           1(SUCCESS): 成功
 * @note   该函数用户不能修改
 */
u8 dp_download_handle(u8 dpid,const u8 value[], u16 length)
{
    /*********************************
    当前函数处理可下发/可上报数据调用                    
    具体函数内需要实现下发数据处理
    完成用需要将处理结果反馈至APP端,否则APP会认为下发失败
    ***********************************/
    u8 ret;
    switch(dpid)
    {

        
        default:
        break;
    }
    return ret;
}

/**
 * @brief  获取所有dp命令总和
 * @param[in] Null
 * @return 下发命令总和
 * @note   该函数用户不能修改
 */
u8 get_download_cmd_total(void)
{
    return(sizeof(download_cmd) / sizeof(download_cmd[0]));
}


/******************************************************************************
                                WARNING!!!                     
此代码为SDK内部调用,请按照实际dp数据实现函数内部数据
******************************************************************************/
#ifdef SUPPORT_MCU_RTC_CHECK
/**
 * @brief  MCU校对本地RTC时钟
 * @param[in] {time} 获取的时间数据
 * @return 无
 * @note   MCU需要自行实现该功能
 */
void mcu_write_rtctime(u8 time[])
{
    #error "请自行完成RTC时钟写入代码,并删除该行"
    /*
    time[0] 为是否获取时间成功标志，为 0 表示失败，为 1 表示成功
    time[1] 为年份，0x00 表示 2000 年
    time[2] 为月份，从 1 开始到 12 结束
    time[3] 为日期，从 1 开始到 31 结束
    time[4] 为时钟，从 0 开始到 23 结束
    time[5] 为分钟，从 0 开始到 59 结束
    time[6] 为秒钟，从 0 开始到 59 结束
    time[7] 为星期，从 1 开始到 7 结束，1 代表星期一
    */
    if(time[0] == 1)
    {
        //正确接收到wifi模块返回的本地时钟数据

    }
    else
    {
        //获取本地时钟数据出错,有可能是当前wifi模块未联网
    }
}
#endif

#ifdef WIFI_TEST_ENABLE
/**
 * @brief  wifi功能测试反馈
 * @param[in] {result} wifi功能测试结果
 * @ref       0: 失败
 * @ref       1: 成功
 * @param[in] {rssi} 测试成功表示wifi信号强度/测试失败表示错误类型
 * @return Null
 * @note   MCU需要自行实现该功能
 */
void wifi_test_result(u8 result,u8 rssi)
{
    #error "请自行实现wifi功能测试成功/失败代码,完成后请删除该行"
    if(result == 0)
    {
        //测试失败
        if(rssi == 0x00)
        {
            //未扫描到名称为tuya_mdev_test路由器,请检查
        }
        else if(rssi == 0x01)
        {
            //模块未授权
        }
    }
    else
    {
        //测试成功
        //rssi为信号强度(0-100, 0信号最差，100信号最强)
    }
}
#endif

#ifdef WIFI_MODULE_UPDATE
/**
 * @brief  请求 WIFI 模块固件升级结果返回
 * @param[in] {result} 请求 WIFI 模块固件升级结果;
 * @ref    0x00(开始检测固件更新) 不可断电
 * @ref    0x01(已经是最新固件) 断电
 * @ref    0x02(正在更新固件) 不可断电
 * @ref    0x03(固件更新成功) 断电
 * @ref    0x04(固件更新失败) 断电
 * @return 无
 * @note   MCU需要自行实现该功能
 */
void qur_module_ug_result(u8 result)
{
    #error "请自行实施请求WIFI模块固件升级结果返回码。 请在完成后删除该行"
    switch(result) 
    {
        case 0:
        //(开始检测固件更新）不可断电
        
        break;
        case 1:
        //（已经是最新固件） 断电
        
        break;
        case 2:
        //(正在更新固件）不可断电
        
        break;
        case 3:
        //(固件更新成功）断电
        
        break;
        case 4:
        //(固件更新失败）断电
        
        break;
        default:
        break;
    }
}
#endif

#ifdef WIFI_QUERY_ROUTE_RSSI
/**
 * @brief  查询当前连接路由器信号强度
 * @param[in] {result} wifi功能测试结果;0:失败/1:成功
 * @param[in] {rssi} 测试成功表示wifi信号强度/测试失败表示错误类型
 * @return 无
 * @note   MCU需要自行实现该功能
 */
void router_strenth_result(u8 result,u8 rssi)
{
    #error "请自行实现查询当前连接路由器信号强度处理代码,完成后请删除该行"
    if(result == 0)
    {
        //未连上路由,请检查
        if(rssi == 0x00)
        {
            //未连上路由,请检查
        }
        else if(rssi == 0x01)
        {
            //模块未授权
        }
    }
    else
    {
        //测试成功
        //rssi为信号强度(0-100, 0信号最差，100信号最强)
    }
}
#endif

#ifdef SUPPORT_MCU_FIRM_UPDATE
/**
 * @brief  请求 MCU 固件升级结果返回
 * @param[in] {result} 结果返回
 * @return 无
 * @note   MCU需要自行实现该功能
 */
void qur_ug_result(u8 result)
{
    #error "请自行实现请求 MCU 固件升级结果返回处理代码,完成后请删除该行"
    switch(result) 
    {
        case 0:
            //(开始检测固件更新）不可断电
            
        break;
        case 1:
            //（已经是最新固件） 断电
            
        break;
        case 2:
            //(正在更新固件）不可断电
            
        break;
        case 3:
            //(固件更新成功）断电
        
        break;
        case 4:
            //(固件更新失败）断电
            
        break;
        default:
        break;
    }
}

/**
 * @brief  升级包大小选择
 * @param[in] {package_sz} 升级包大小
 * @ref           0x00: 256byte (默认)
 * @ref           0x01: 512byte
 * @ref           0x02: 1024byte
 * @return 无
 * @note   MCU需要自行实现该功能
 */
void upgrade_package_choose(u8 package_sz)
{
    #error "请自行实现wifi功能测试成功/失败代码,完成后请删除该行"
    u16 length = 0;
    length = set_wifi_uart_byte(length,package_sz);
    wifi_uart_write_frame(UPDATE_START_CMD,length);
}

/**
 * @brief  MCU固件升级数据处理
 * @param[in] {value} 固件缓冲区
 * @param[in] {position} 当前数据包在于固件位置
 * @param[in] {length} 当前固件包长度(固件包长度为0时,表示固件包发送完成)
 * @return 无
 * @note   MCU需要自行实现该功能
 */
u8 mcu_firm_update_handle(const u8 value[],u32 position,u16 length)
{
    #error "请自行完成MCU固件升级数据处理代码,完成后请删除该行"
    if(length == 0)
    {
        //固件数据发送完成
        
    }
    else
    {
        //固件数据处理
    }

    return SUCCESS;
}
#endif

