/**********************************Copyright (c)**********************************
**                       版权所有 (C), 2015-2020, 涂鸦科技
**
**                             http://www.tuya.com
**
*********************************************************************************/
/**
 * @file    system.h
 * @author  涂鸦综合协议开发组
 * @version v1.0.5
 * @date    2021.10.19
 * @brief   串口数据处理。用户无需关心文件实现内容。
 */

/****************************** 免责声明 ！！！ *******************************
由于MCU类型和编译环境多种多样，所以此代码仅供参考，用户请自行把控最终代码质量，
涂鸦不对MCU功能结果负责。
******************************************************************************/

#ifndef __SYSTEM_H_
#define __SYSTEM_H_

#include "tuya_type.h"

#ifdef SYSTEM_GLOBAL
    #define SYSTEM_EXTERN
#else
    #define SYSTEM_EXTERN   extern
#endif

//=============================================================================
//帧的字节顺序
//=============================================================================
#define         HEAD_FIRST                      0
#define         HEAD_SECOND                     1        
#define         PROTOCOL_VERSION                2
#define         FRAME_TYPE                      3
#define         LENGTH_HIGH                     4
#define         LENGTH_LOW                      5
#define         DATA_START                      6

//=============================================================================
//数据帧类型
//=============================================================================
#define         PRODUCT_INFO_CMD                1                               //产品信息
#define         WIFI_STATE_CMD                  2                               //wifi工作状态
#define         WIFI_RESET_CMD                  3                               //重置wifi
#define         WIFI_MODE_CMD                   4                               //选择smartconfig/AP模式
#define         STATE_UPLOAD_CMD                5                               //实时状态上报
#define         GET_LOCAL_TIME_CMD              6                               //获取本地时间
#define         WIFI_TEST_CMD                   7                               //wifi功能测试
#define         STATE_RC_UPLOAD_CMD             8                               //记录型状态上报
#define         DATA_QUERT_CMD                  9                               //命令下发
#define         WIFI_UPDATE_CMD                 0x0a                            //请求WIFI模块固件升级
#define         ROUTE_RSSI_CMD                  0x0b                            //查询当前连接路由器信号强度
#define         REQUEST_MCU_UG_CMD              0x0c                            //请求mcu固件升级
#define         UPDATE_START_CMD                0x0d                            //mcu升级包大小通知（升级开始）
#define         UPDATE_TRANS_CMD                0x0e                            //升级传输
#define         GET_DP_CACHE_CMD                0x10                            //获取dp缓存指令

//=============================================================================
#define VERSION                 0x00                                            //协议版本号
#define PROTOCOL_HEAD           0x07                                            //固定协议头长度
#define FIRM_UPDATA_SIZE        256                                             //升级包大小
#define FRAME_FIRST             0x55
#define FRAME_SECOND            0xaa
//============================================================================= 
SYSTEM_EXTERN u8 wifi_data_process_buf[PROTOCOL_HEAD + WIFI_DATA_PROCESS_LMT];         //串口数据处理缓冲
SYSTEM_EXTERN u8 volatile wifi_uart_rx_buf[PROTOCOL_HEAD + WIFI_UART_RECV_BUF_LMT];    //串口接收缓存
SYSTEM_EXTERN u8 wifi_uart_tx_buf[PROTOCOL_HEAD + WIFIR_UART_SEND_BUF_LMT];            //串口发送缓存
SYSTEM_EXTERN volatile u8 *queue_in;
SYSTEM_EXTERN volatile u8 *queue_out;

SYSTEM_EXTERN u8 stop_update_flag;                                   //ENABLE:停止所有数据上传   DISABLE:恢复所有数据上传

#ifndef WIFI_CONTROL_SELF_MODE
SYSTEM_EXTERN u8 reset_wifi_flag;                                    //重置wifi标志(TRUE:成功/FALSE:失败)
SYSTEM_EXTERN u8 set_wifimode_flag;                                  //设置WIFI工作模式标志(TRUE:成功/FALSE:失败)
SYSTEM_EXTERN u8 wifi_work_state;                                    //wifi模块当前工作状态
#endif


/**
 * @brief  写wifi_uart字节
 * @param[in] {dest} 缓存区其实地址
 * @param[in] {byte} 写入字节值
 * @return 写入完成后的总长度
 */
u16 set_wifi_uart_byte(u16 dest, u8 byte);

/**
 * @brief  写wifi_uart_buffer
 * @param[in] {dest} 目标地址
 * @param[in] {src} 源地址
 * @param[in] {len} 数据长度
 * @return 写入结束的缓存地址
 */
u16 set_wifi_uart_buffer(u16 dest, u8 *src, u16 len);

/**
 * @brief  向wifi串口发送一帧数据
 * @param[in] {fr_type} 帧类型
 * @param[in] {len} 数据长度
 * @return Null
 */
void wifi_uart_write_frame(u8 fr_type, u16 len);

/**
 * @brief  计算校验和
 * @param[in] {pack} 数据源指针
 * @param[in] {pack_len} 计算校验和长度
 * @return 校验和
 */
u8 get_check_sum(u8 *pack, u16 pack_len);

/**
 * @brief  数据帧处理
 * @param[in] {offset} 数据起始位
 * @return Null
 */
void data_handle(u16 offset);

/**
 * @brief  判断uart接收缓冲区是否有数据
 * @param  无
 * @return 是否有数据
 */
u8 get_queue_total_data(void);

/**
 * @brief  读取队列1字节数据
 * @param  无
 * @return 读到的数据
 */
u8 Queue_Read_Byte(void);

#endif
  
  
